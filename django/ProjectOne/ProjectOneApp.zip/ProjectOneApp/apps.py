from django.apps import AppConfig


class ProjectoneappConfig(AppConfig):
    name = 'ProjectOneApp'
