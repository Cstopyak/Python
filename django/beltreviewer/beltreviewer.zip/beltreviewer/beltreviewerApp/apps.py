from django.apps import AppConfig


class BeltreviewerappConfig(AppConfig):
    name = 'beltreviewerApp'
