from django.apps import AppConfig


class NumbersgameappConfig(AppConfig):
    name = 'NumbersGameApp'
