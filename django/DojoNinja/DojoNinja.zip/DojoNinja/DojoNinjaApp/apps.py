from django.apps import AppConfig


class DojoninjaappConfig(AppConfig):
    name = 'DojoNinjaApp'
