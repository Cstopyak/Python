from django.apps import AppConfig


class DojosurveyappConfig(AppConfig):
    name = 'DojoSurveyApp'
