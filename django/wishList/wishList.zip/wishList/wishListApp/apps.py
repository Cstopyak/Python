from django.apps import AppConfig


class WishlistappConfig(AppConfig):
    name = 'wishListApp'
