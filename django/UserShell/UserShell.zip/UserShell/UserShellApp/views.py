from django.shortcuts import render, HttpResponse, redirect
from .models import Model_orm

def index(request):
    print(Model_orm.objects.all())
    context = {
        'allModel': Model_orm.objects.all()
    }


    return render(request,"index.html", context)

def newuser(request):
    print("success!")
    print(request.POST)
    Model_orm.objects.create(fname= request.POST['fname'], lname= request.POST['lname'],email= request.POST['email'], age= request.POST['age'] )
    return redirect("/")