from django.apps import AppConfig


class UsershellappConfig(AppConfig):
    name = 'UserShellApp'
