class User:
    def __init__(self, nameInput):
        # Attributes
        self.name = nameInput
        self.balance = 0
        

    # Methods
    def make_withdrawal(self, withdrawal):
        self.balance -= withdrawal
        return self

    def make_deposit(self, deposit):
        self.balance += deposit
        return self

    # def transer_money(self, transfer):
    #     self.balance -= transfer

    def display_user_balance(self):
        print(f"User:{self.name}, balance: {self.balance}")


U1 = User("Colby")
U2 = User("Emily")
U3 = User("Tina")


print(U1.balance)

U1.make_deposit(100),U1. make_deposit(110),U1.make_withdrawal(60).display_user_balance()
U2.make_deposit(400), U2.make_deposit(100), U2.make_withdrawal(50), U2.make_withdrawal(50).display_user_balance()
U3.make_deposit(250), U3.make_withdrawal(25), U3.make_withdrawal(20), U3.make_withdrawal(20).display_user_balance()

